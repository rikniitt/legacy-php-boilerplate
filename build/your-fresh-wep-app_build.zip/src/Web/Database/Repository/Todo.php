<?php

namespace Web\Database\Repository;

use Web\Database\Repository;

class Todo extends Repository
{
    protected $modelName = 'Web\Database\Model\Todo';
}
