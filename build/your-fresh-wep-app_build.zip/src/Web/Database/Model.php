<?php

namespace Web\Database;

abstract class Model
{

}
